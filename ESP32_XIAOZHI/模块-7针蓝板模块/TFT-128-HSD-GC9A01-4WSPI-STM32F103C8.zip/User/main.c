
/********************���ݳ�����**************************
STM32F103C8T6
LCD: HSD1.28
IC: GC9A01
***** PB5    SCK
      PB6    SDA
      PB7    RESET
      PB8    D/C
      PB9    CS
******************************************************/
#include "stm32f10x.h"
#include "led.h"
#include "key.h"  
#include "bmp.h"  
//#include "lcdfont.h"  

#define DIS_DIR  0
#define USE_HORIZONTAL 1  //���ú�������������ʾ 0��1Ϊ���� 2��3Ϊ����

#define TFT_COLUMN_NUMBER 240
#define TFT_LINE_NUMBER 240

#define TFT_COLUMN_OFFSET 0
#define TFT_LINE_OFFSET 0

/**********SPI���ŷ��䣬����TFT��������ʵ������޸�*********/

#define TFT_SCK_0  GPIOA->BRR=0X0001       // ����sck�ӿڵ�PA0
#define TFT_SCK_1  GPIOA->BSRR=0X0001       //

#define TFT_SDA_0  GPIOA->BRR=0X0002       // ����SDA�ӿڵ�PA1
#define TFT_SDA_1  GPIOA->BSRR=0X0002

#define TFT_RST_0  GPIOA->BRR=0X0004       // ����DC�ӿڵ�PA2
#define TFT_RST_1  GPIOA->BSRR=0X0004

#define TFT_DC_0   GPIOA->BRR=0X0008      // ����CS�ӿڵ�PA3
#define TFT_DC_1   GPIOA->BSRR=0X0008

#define TFT_CS_0   GPIOA->BRR=0X0010    // ����RST�ӿڵ�PA4
#define TFT_CS_1   GPIOA->BSRR=0X0010


//#define TFT_SCK_0  GPIOB->BRR=0X0020       // ����sck�ӿڵ�PB5
//#define TFT_SCK_1  GPIOB->BSRR=0X0020       //

//#define TFT_SDA_0  GPIOB->BRR=0X0040       // ����SDA�ӿڵ�PB6
//#define TFT_SDA_1  GPIOB->BSRR=0X0040

//#define TFT_RST_0  GPIOB->BRR=0X0080       // ����DC�ӿڵ�PB7
//#define TFT_RST_1  GPIOB->BSRR=0X0080

//#define TFT_DC_0   GPIOB->BRR=0X0100      // ����CS�ӿڵ�PB8
//#define TFT_DC_1   GPIOB->BSRR=0X0100

//#define TFT_CS_0   GPIOB->BRR=0X0200    // ����RST�ӿڵ�PB9
//#define TFT_CS_1   GPIOB->BSRR=0X0200




/*
#define TFT_BL_0  GPIOB->BRR=0x0010       //PB4
#define TFT_BL_1  GPIOB->BSRR=0x0010

#define TFT_CS_0  GPIOB->BRR=0X0020      //PB5
#define TFT_CS_1  GPIOB->BSRR=0X0020

#define TFT_DC_0  GPIOB->BRR=0X0040      //PB6
#define TFT_DC_1  GPIOB->BSRR=0X0040 

#define TFT_RST_0  GPIOB->BRR=0x0080      //PB7
#define TFT_RST_1  GPIOB->BSRR=0x0080

#define TFT_SDA_0   GPIOB->BRR=0X0100      //PB8
#define TFT_SDA_1   GPIOB->BSRR=0X0100

#define TFT_SCK_0   GPIOB->BRR=0X0200      //PB9
#define TFT_SCK_1   GPIOB->BSRR=0X0200
*/


/*****************��ɫ����**************************/
#define WHITE            0xFFFF
#define BLACK            0x0000   
#define BLUE             0x001F  
#define BRED             0XF81F
#define GRED             0XFFE0
#define GBLUE            0X07FF
#define RED              0xF800
#define GREEN            0x07E0

unsigned int page = 0;
unsigned int autoplay = 0;

/*******ʱ�ӳ�ʼ��******************/
void SYS_init(unsigned char PLL)
{
	RCC->APB1RSTR = 0x00000000;//��λ����			 
	RCC->APB2RSTR = 0x00000000; 	  
	RCC->AHBENR = 0x00000014;  //˯��ģʽ�����SRAMʱ��ʹ��.�����ر�.	  
	RCC->APB2ENR = 0x00000000; //����ʱ�ӹر�.			   
	RCC->APB1ENR = 0x00000000;   
	RCC->CR |= 0x00000001;     //ʹ���ڲ�����ʱ��HSION
	
	RCC->CFGR &= 0xF8FF0000;   //��λSW[1:0],HPRE[3:0],PPRE1[2:0],PPRE2[2:0],ADCPRE[1:0],MCO[2:0]					 
	RCC->CR &= 0xFEF6FFFF;     //��λHSEON,CSSON,PLLON
	RCC->CR &= 0xFFFBFFFF;     //��λHSEBYP	   	  
	RCC->CFGR &= 0xFF80FFFF;   //��λPLLSRC, PLLXTPRE, PLLMUL[3:0] and USBPRE
	while(((RCC->CFGR>>2)& 0x03 )!=0x00); 	
	RCC->CIR = 0x00000000;     //�ر������ж�		 
	//����������				  
  
//	SCB->VTOR = 0x08000000|(0x0 & (u32)0x1FFFFF80);//����NVIC��������ƫ�ƼĴ���

 	RCC->CR|=0x00010000;  //�ⲿ����ʱ��ʹ��HSEON
	while(((RCC->CR>>17)&0x00000001)==0);//�ȴ��ⲿʱ�Ӿ���
	RCC->CFGR=0X00000400; //APB1=DIV2;APB2=DIV1;AHB=DIV1;
	PLL-=2;//����2����λ
	RCC->CFGR|=PLL<<18;   //����PLLֵ 2~16
	RCC->CFGR|=1<<16;	  //PLLSRC ON 
	

	RCC->CR|=0x01000000;  //PLLON
	while(!(RCC->CR>>25));//�ȴ�PLL����
	RCC->CFGR|=0x00000002;//PLL��Ϊϵͳʱ��	 
	while(((RCC->CFGR>>2)&0x03)!=0x02);   //�ȴ�PLL��Ϊϵͳʱ�����óɹ�
}

void IO_init(void)
{
	RCC->APB2ENR|=1<<2;    //??PORTA??
	RCC->APB2ENR|=1<<3;    //??PORTB?? 
	
	GPIOA->CRL&=0X00000000;				//?PA??????????,??50MH
	GPIOA->CRL|=0X33333333;				
	
	GPIOA->ODR=0XFFFF;

//	RCC->APB2ENR|=1<<2;    //ʹ��PORTAʱ��
//	RCC->APB2ENR|=1<<3;    //ʹ��PORTBʱ�� 
//	RCC->APB2ENR|=1<<4;    //ʹ��PORTCʱ��

//	GPIOB->CRL	&=  0X00000000;				//��B34567������Ϊͨ���������,���50MH
//	GPIOB->CRL	|=	0X33300000;				
//	GPIOB->CRH	&=	0X00000000;				//��PB������Ϊͨ���������,���50MH
//	GPIOB->CRH	|=	0X00033333;
//	GPIOB->ODR	=0XFFFF;
}

void delay_us(unsigned int _us_time)
{       
	unsigned char x=0;
	for(;_us_time>0;_us_time--)
	{
		x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;
	}
}

void delay_ms(unsigned int _ms_time)
{
	unsigned int x, i, j;
	for(i=0;i<_ms_time;i++)
	{
		for(j=0;j<1000;j++)
		{
			x++;//x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;
		}
	}
}

/*************SPI���ú���*******************
��SCL����ʱ�͵�ƽ����һ�������ز���
ģ��SPI
******************************************/

/**************************SPIģ�鷢�ͺ���************************************************

 *************************************************************************/
void SPI_SendByte(unsigned char byte)
{
	unsigned char counter;

	for(counter=0;counter<8;counter++)
	{ 
		TFT_SCK_0;
	  
		if((byte&0x80)==0)
		{
			TFT_SDA_0;
		}else{
			TFT_SDA_1;
		}
	  
		byte=byte<<1;
	
		TFT_SCK_1;	
	} 
	TFT_SCK_0;
}

void TFT_SEND_CMD(unsigned char o_command)
{
  TFT_CS_0;
	TFT_DC_0;
	SPI_SendByte(o_command);
  TFT_CS_1;
	//TFT_DC_1;
}

void TFT_SEND_DATA(unsigned char o_data)
{ 
	TFT_CS_0;
	TFT_DC_1;
	SPI_SendByte(o_data);
	TFT_CS_1;
}

void TFT_SET_ADD(unsigned short int X,unsigned short int Y,unsigned short int X_END,unsigned short int Y_END)
{	
	TFT_SEND_CMD(0x2A);     //���ڵ�ַ����                   
    TFT_SEND_DATA(X>>8);     
    TFT_SEND_DATA(X);//start column
	TFT_SEND_DATA(X_END>>8);     
    TFT_SEND_DATA(X_END);//start column
	TFT_SEND_CMD(0x2B);     //���ڵ�ַ����                   
    TFT_SEND_DATA(Y>>8);     
    TFT_SEND_DATA(Y);		//start row
    TFT_SEND_DATA(Y_END>>8);     
    TFT_SEND_DATA(Y_END);		//start row
    TFT_SEND_CMD(0x2C);     //д������   
}

void TFT_init(void)	//GC9A01
{
	TFT_RST_0;//��λ 
	delay_ms(100); 
	TFT_RST_1; 
	delay_ms(100); 


	  
	  TFT_SEND_CMD(0xEF); 		//ʹ��ָ��2
	  TFT_SEND_CMD(0xEB); 		//
	  TFT_SEND_DATA(0x14);
	  
	  TFT_SEND_CMD(0xFE); 		//ʹ��ָ��1
	  TFT_SEND_CMD(0xEF); 		//ʹ��ָ��2  ����interָ�������ɣ���λ֮��ſɹر�
	  
	  TFT_SEND_CMD(0xEB); 
	  TFT_SEND_DATA(0x14); 
	  
	  TFT_SEND_CMD(0x84); 
	  TFT_SEND_DATA(0x40); 
	  TFT_SEND_CMD(0x85); 
	  TFT_SEND_DATA(0xFF); 
	  TFT_SEND_CMD(0x86); 
	  TFT_SEND_DATA(0xFF); 
	  TFT_SEND_CMD(0x87); 
	  TFT_SEND_DATA(0xFF); 
	  TFT_SEND_CMD(0x88); 
	  TFT_SEND_DATA(0x0A); 
	  TFT_SEND_CMD(0x89); 
	  TFT_SEND_DATA(0x21);
	  
	  TFT_SEND_CMD(0x8A); 
	  TFT_SEND_DATA(0x00);
	  
	  TFT_SEND_CMD(0x8B); 
	  TFT_SEND_DATA(0x80);
	  
	  TFT_SEND_CMD(0x8C); 
	  TFT_SEND_DATA(0x01);
	  
	  TFT_SEND_CMD(0x8D); 
	  TFT_SEND_DATA(0x01);
	  
	  TFT_SEND_CMD(0x8E); 
	  TFT_SEND_DATA(0xFF);
	  
	  TFT_SEND_CMD(0x8F); 
	  TFT_SEND_DATA(0xFF);
	  
	  TFT_SEND_CMD(0xB6); 	//�ⲿָ��  ��ʾ���ܿ���
	  TFT_SEND_DATA(0x00); 		//ɨ�跽�����S1-S360 G1-32
	  TFT_SEND_DATA(0x20); 		
	  
	  TFT_SEND_CMD(0x36); 	//����ָ�� �洢���� Memory Access Control
	  TFT_SEND_DATA(0x08); 		//MY MX MV ML BGR MH X X
	  
	  TFT_SEND_CMD(0x3A); 	//����ָ�� 	Pixel Format Set
	  TFT_SEND_DATA(0x05); 			//16bit MCU����ģʽ
	  
	  TFT_SEND_CMD(0x90); 	//xxx
	  TFT_SEND_DATA(0x08); 
	  TFT_SEND_DATA(0x08); 
	  TFT_SEND_DATA(0x08); 
	  TFT_SEND_DATA(0x08);
	  
	  TFT_SEND_CMD(0xBD); 	//XXX
	  TFT_SEND_DATA(0x06);
	  
	  TFT_SEND_CMD(0xBC); 	//XXX
	  TFT_SEND_DATA(0x00); 
	  
	  TFT_SEND_CMD(0xFF); 	//XXX	
	  TFT_SEND_DATA(0x60); 
	  TFT_SEND_DATA(0x01); 
	  TFT_SEND_DATA(0x04);
	  
	  TFT_SEND_CMD(0xC3); 	//	Vreg1a voltage Control
	  TFT_SEND_DATA(0x13);
	  
	  TFT_SEND_CMD(0xC4); 	// Vreg1b voltage Control
	  TFT_SEND_DATA(0x13);
	  
	  TFT_SEND_CMD(0xC9); 	//Vreg2a voltage Control
	  TFT_SEND_DATA(0x22);
	  
	  TFT_SEND_CMD(0xBE); 	//XXX
	  TFT_SEND_DATA(0x11); 
	  
	  TFT_SEND_CMD(0xE1); 	//XXX
	  TFT_SEND_DATA(0x10);
	  TFT_SEND_DATA(0x0E); 
	  
	  TFT_SEND_CMD(0xDF); 	//XXX
	  TFT_SEND_DATA(0x21); 
	  TFT_SEND_DATA(0x0c); 
	  TFT_SEND_DATA(0x02); 
	  
	  TFT_SEND_CMD(0xF0); 	//GAMMA1
	  TFT_SEND_DATA(0x45); 
	  TFT_SEND_DATA(0x09); 
	  TFT_SEND_DATA(0x08); 
	  TFT_SEND_DATA(0x08); 
	  TFT_SEND_DATA(0x26); 
	  TFT_SEND_DATA(0x2A); 
	  
	  TFT_SEND_CMD(0xF1); 	//GAMMA2
	  TFT_SEND_DATA(0x43); 
	  TFT_SEND_DATA(0x70); 
	  TFT_SEND_DATA(0x72); 
	  TFT_SEND_DATA(0x36); 
	  TFT_SEND_DATA(0x37); 
	  TFT_SEND_DATA(0x6F); 
	  
	  TFT_SEND_CMD(0xF2); 	//GAMMA3
	  TFT_SEND_DATA(0x45); 
	  TFT_SEND_DATA(0x09); 
	  TFT_SEND_DATA(0x08); 
	  TFT_SEND_DATA(0x08); 
	  TFT_SEND_DATA(0x26); 
	  TFT_SEND_DATA(0x2A); 
	  
	  TFT_SEND_CMD(0xF3); 	////GAMMA4
	  TFT_SEND_DATA(0x43); 
	  TFT_SEND_DATA(0x70); 
	  TFT_SEND_DATA(0x72); 
	  TFT_SEND_DATA(0x36); 
	  TFT_SEND_DATA(0x37); 
	  TFT_SEND_DATA(0x6F);
	  
	  TFT_SEND_CMD(0xED); 	//XXX
	  TFT_SEND_DATA(0x1B); 
	  TFT_SEND_DATA(0x0B);
	  
	  TFT_SEND_CMD(0xAE); 	//XXX
	  TFT_SEND_DATA(0x77);
	  
	  TFT_SEND_CMD(0xCD); 	//XXX
	  TFT_SEND_DATA(0x63);
	  
	  TFT_SEND_CMD(0x70); 
	  TFT_SEND_DATA(0x07); 
	  TFT_SEND_DATA(0x07); 
	  TFT_SEND_DATA(0x04); 
	  TFT_SEND_DATA(0x0E); 
	  TFT_SEND_DATA(0x0F); 
	  TFT_SEND_DATA(0x09); 
	  TFT_SEND_DATA(0x07); 
	  TFT_SEND_DATA(0x08); 
	  TFT_SEND_DATA(0x03); 
	  
	  TFT_SEND_CMD(0xE8); 	//Frame Rate
	  TFT_SEND_DATA(0x34);
	  
	  TFT_SEND_CMD(0x62); 	//XXX
	  TFT_SEND_DATA(0x18); 
	  TFT_SEND_DATA(0x0D); 
	  TFT_SEND_DATA(0x71); 
	  TFT_SEND_DATA(0xED); 
	  TFT_SEND_DATA(0x70); 
	  TFT_SEND_DATA(0x70); 
	  TFT_SEND_DATA(0x18); 
	  TFT_SEND_DATA(0x0F); 
	  TFT_SEND_DATA(0x71); 
	  TFT_SEND_DATA(0xEF); 
	  TFT_SEND_DATA(0x70); 
	  TFT_SEND_DATA(0x70); 
	  
	  TFT_SEND_CMD(0x63); 	//XXX
	  TFT_SEND_DATA(0x18); 
	  TFT_SEND_DATA(0x11); 
	  TFT_SEND_DATA(0x71); 
	  TFT_SEND_DATA(0xF1); 
	  TFT_SEND_DATA(0x70); 
	  TFT_SEND_DATA(0x70); 
	  TFT_SEND_DATA(0x18); 
	  TFT_SEND_DATA(0x13); 
	  TFT_SEND_DATA(0x71); 
	  TFT_SEND_DATA(0xF3); 
	  TFT_SEND_DATA(0x70); 
	  TFT_SEND_DATA(0x70); 
	  
	  TFT_SEND_CMD(0x64); 	//XXX
	  TFT_SEND_DATA(0x28); 
	  TFT_SEND_DATA(0x29); 
	  TFT_SEND_DATA(0xF1); 
	  TFT_SEND_DATA(0x01); 
	  TFT_SEND_DATA(0xF1); 
	  TFT_SEND_DATA(0x00); 
	  TFT_SEND_DATA(0x07);
	  
	  TFT_SEND_CMD(0x66); 	//XXX
	  TFT_SEND_DATA(0x3C); 
	  TFT_SEND_DATA(0x00); 
	  TFT_SEND_DATA(0xCD); 
	  TFT_SEND_DATA(0x67); 
	  TFT_SEND_DATA(0x45); 
	  TFT_SEND_DATA(0x45); 
	  TFT_SEND_DATA(0x10); 
	  TFT_SEND_DATA(0x00); 
	  TFT_SEND_DATA(0x00); 
	  TFT_SEND_DATA(0x00); 
	  
	  TFT_SEND_CMD(0x67); 	//XXX
	  TFT_SEND_DATA(0x00); 
	  TFT_SEND_DATA(0x3C); 
	  TFT_SEND_DATA(0x00); 
	  TFT_SEND_DATA(0x00); 
	  TFT_SEND_DATA(0x00); 
	  TFT_SEND_DATA(0x01); 
	  TFT_SEND_DATA(0x54); 
	  TFT_SEND_DATA(0x10); 
	  TFT_SEND_DATA(0x32); 
	  TFT_SEND_DATA(0x98);
	  
	  TFT_SEND_CMD(0x74); 	//XXX
	  TFT_SEND_DATA(0x10); 
	  TFT_SEND_DATA(0x85); 
	  TFT_SEND_DATA(0x80); 
	  TFT_SEND_DATA(0x00); 
	  TFT_SEND_DATA(0x00); 
	  TFT_SEND_DATA(0x4E); 
	  TFT_SEND_DATA(0x00);
	  
	  TFT_SEND_CMD(0x98); 		//XXX
	  TFT_SEND_DATA(0x3e); 
	  TFT_SEND_DATA(0x07); 
	  
	  TFT_SEND_CMD(0x34); 	//Tearing Effect Line Off
	  TFT_SEND_CMD(0x21); 	//Display Inversion ON
	  TFT_SEND_CMD(0x11); 	//����
	  //TFT_SEND_CMD(0x38);	//Idle Mode OFF
	  delay_ms(120); 
	  TFT_SEND_CMD(0x29); 	//��ʾ��
	  delay_ms(20);
}



void TFT_init2(void)	//GC9A01
{
	  TFT_SEND_CMD(0xEF); 		//ʹ��ָ��2
	  TFT_SEND_CMD(0xEB); 		//
	  TFT_SEND_DATA(0x14);
	  
	  TFT_SEND_CMD(0xFE); 		//ʹ��ָ��1
	  TFT_SEND_CMD(0xEF); 		//ʹ��ָ��2  ����interָ�������ɣ���λ֮��ſɹر�
	  
	  TFT_SEND_CMD(0xEB); 
	  TFT_SEND_DATA(0x14); 
	  
	  TFT_SEND_CMD(0x84); 
	  TFT_SEND_DATA(0x40); 
	  TFT_SEND_CMD(0x85); 
	  TFT_SEND_DATA(0xFF); 
	  TFT_SEND_CMD(0x86); 
	  TFT_SEND_DATA(0xFF); 
	  TFT_SEND_CMD(0x87); 
	  TFT_SEND_DATA(0xFF); 
	  TFT_SEND_CMD(0x88); 
	  TFT_SEND_DATA(0x0A); 
	  TFT_SEND_CMD(0x89); 
	  TFT_SEND_DATA(0x21);
	  
	  TFT_SEND_CMD(0x8A); 
	  TFT_SEND_DATA(0x00);
	  
	  TFT_SEND_CMD(0x8B); 
	  TFT_SEND_DATA(0x80);
	  
	  TFT_SEND_CMD(0x8C); 
	  TFT_SEND_DATA(0x01);
	  
	  TFT_SEND_CMD(0x8D); 
	  TFT_SEND_DATA(0x01);
	  
	  TFT_SEND_CMD(0x8E); 
	  TFT_SEND_DATA(0xFF);
	  
	  TFT_SEND_CMD(0x8F); 
	  TFT_SEND_DATA(0xFF);
	  
	  TFT_SEND_CMD(0xB6); 	//�ⲿָ��  ��ʾ���ܿ���
	  TFT_SEND_DATA(0x00); 		//ɨ�跽�����S1-S360 G1-32
	  TFT_SEND_DATA(0x20); 		
	  
	  TFT_SEND_CMD(0x36); 	//����ָ�� �洢���� Memory Access Control
	  TFT_SEND_DATA(0x08); 		//MY MX MV ML BGR MH X X
	  
	  TFT_SEND_CMD(0x3A); 	//����ָ�� 	Pixel Format Set
	  TFT_SEND_DATA(0x05); 			//16bit MCU����ģʽ
	  
	  TFT_SEND_CMD(0x90); 	//xxx
	  TFT_SEND_DATA(0x08); 
	  TFT_SEND_DATA(0x08); 
	  TFT_SEND_DATA(0x08); 
	  TFT_SEND_DATA(0x08);
	  
	  TFT_SEND_CMD(0xBD); 	//XXX
	  TFT_SEND_DATA(0x06);
	  
	  TFT_SEND_CMD(0xBC); 	//XXX
	  TFT_SEND_DATA(0x00); 
	  
	  TFT_SEND_CMD(0xFF); 	//XXX	
	  TFT_SEND_DATA(0x60); 
	  TFT_SEND_DATA(0x01); 
	  TFT_SEND_DATA(0x04);
	  
	  TFT_SEND_CMD(0xC3); 	//	Vreg1a voltage Control
	  TFT_SEND_DATA(0x13);
	  
	  TFT_SEND_CMD(0xC4); 	// Vreg1b voltage Control
	  TFT_SEND_DATA(0x13);
	  
	  TFT_SEND_CMD(0xC9); 	//Vreg2a voltage Control
	  TFT_SEND_DATA(0x22);
	  
	  TFT_SEND_CMD(0xBE); 	//XXX
	  TFT_SEND_DATA(0x11); 
	  
	  TFT_SEND_CMD(0xE1); 	//XXX
	  TFT_SEND_DATA(0x10);
	  TFT_SEND_DATA(0x0E); 
	  
	  TFT_SEND_CMD(0xDF); 	//XXX
	  TFT_SEND_DATA(0x21); 
	  TFT_SEND_DATA(0x0c); 
	  TFT_SEND_DATA(0x02); 
	  
	  TFT_SEND_CMD(0xF0); 	//GAMMA1
	  TFT_SEND_DATA(0x45); 
	  TFT_SEND_DATA(0x09); 
	  TFT_SEND_DATA(0x08); 
	  TFT_SEND_DATA(0x08); 
	  TFT_SEND_DATA(0x26); 
	  TFT_SEND_DATA(0x2A); 
	  
	  TFT_SEND_CMD(0xF1); 	//GAMMA2
	  TFT_SEND_DATA(0x43); 
	  TFT_SEND_DATA(0x70); 
	  TFT_SEND_DATA(0x72); 
	  TFT_SEND_DATA(0x36); 
	  TFT_SEND_DATA(0x37); 
	  TFT_SEND_DATA(0x6F); 
	  
	  TFT_SEND_CMD(0xF2); 	//GAMMA3
	  TFT_SEND_DATA(0x45); 
	  TFT_SEND_DATA(0x09); 
	  TFT_SEND_DATA(0x08); 
	  TFT_SEND_DATA(0x08); 
	  TFT_SEND_DATA(0x26); 
	  TFT_SEND_DATA(0x2A); 
	  
	  TFT_SEND_CMD(0xF3); 	////GAMMA4
	  TFT_SEND_DATA(0x43); 
	  TFT_SEND_DATA(0x70); 
	  TFT_SEND_DATA(0x72); 
	  TFT_SEND_DATA(0x36); 
	  TFT_SEND_DATA(0x37); 
	  TFT_SEND_DATA(0x6F);
	  
	  TFT_SEND_CMD(0xED); 	//XXX
	  TFT_SEND_DATA(0x1B); 
	  TFT_SEND_DATA(0x0B);
	  
	  TFT_SEND_CMD(0xAE); 	//XXX
	  TFT_SEND_DATA(0x77);
	  
	  TFT_SEND_CMD(0xCD); 	//XXX
	  TFT_SEND_DATA(0x63);
	  
	  TFT_SEND_CMD(0x70); 
	  TFT_SEND_DATA(0x07); 
	  TFT_SEND_DATA(0x07); 
	  TFT_SEND_DATA(0x04); 
	  TFT_SEND_DATA(0x0E); 
	  TFT_SEND_DATA(0x0F); 
	  TFT_SEND_DATA(0x09); 
	  TFT_SEND_DATA(0x07); 
	  TFT_SEND_DATA(0x08); 
	  TFT_SEND_DATA(0x03); 
	  
	  TFT_SEND_CMD(0xE8); 	//Frame Rate
	  TFT_SEND_DATA(0x34);
	  
	  TFT_SEND_CMD(0x62); 	//XXX
	  TFT_SEND_DATA(0x18); 
	  TFT_SEND_DATA(0x0D); 
	  TFT_SEND_DATA(0x71); 
	  TFT_SEND_DATA(0xED); 
	  TFT_SEND_DATA(0x70); 
	  TFT_SEND_DATA(0x70); 
	  TFT_SEND_DATA(0x18); 
	  TFT_SEND_DATA(0x0F); 
	  TFT_SEND_DATA(0x71); 
	  TFT_SEND_DATA(0xEF); 
	  TFT_SEND_DATA(0x70); 
	  TFT_SEND_DATA(0x70); 
	  
	  TFT_SEND_CMD(0x63); 	//XXX
	  TFT_SEND_DATA(0x18); 
	  TFT_SEND_DATA(0x11); 
	  TFT_SEND_DATA(0x71); 
	  TFT_SEND_DATA(0xF1); 
	  TFT_SEND_DATA(0x70); 
	  TFT_SEND_DATA(0x70); 
	  TFT_SEND_DATA(0x18); 
	  TFT_SEND_DATA(0x13); 
	  TFT_SEND_DATA(0x71); 
	  TFT_SEND_DATA(0xF3); 
	  TFT_SEND_DATA(0x70); 
	  TFT_SEND_DATA(0x70); 
	  
	  TFT_SEND_CMD(0x64); 	//XXX
	  TFT_SEND_DATA(0x28); 
	  TFT_SEND_DATA(0x29); 
	  TFT_SEND_DATA(0xF1); 
	  TFT_SEND_DATA(0x01); 
	  TFT_SEND_DATA(0xF1); 
	  TFT_SEND_DATA(0x00); 
	  TFT_SEND_DATA(0x07);
	  
	  TFT_SEND_CMD(0x66); 	//XXX
	  TFT_SEND_DATA(0x3C); 
	  TFT_SEND_DATA(0x00); 
	  TFT_SEND_DATA(0xCD); 
	  TFT_SEND_DATA(0x67); 
	  TFT_SEND_DATA(0x45); 
	  TFT_SEND_DATA(0x45); 
	  TFT_SEND_DATA(0x10); 
	  TFT_SEND_DATA(0x00); 
	  TFT_SEND_DATA(0x00); 
	  TFT_SEND_DATA(0x00); 
	  
	  TFT_SEND_CMD(0x67); 	//XXX
	  TFT_SEND_DATA(0x00); 
	  TFT_SEND_DATA(0x3C); 
	  TFT_SEND_DATA(0x00); 
	  TFT_SEND_DATA(0x00); 
	  TFT_SEND_DATA(0x00); 
	  TFT_SEND_DATA(0x01); 
	  TFT_SEND_DATA(0x54); 
	  TFT_SEND_DATA(0x10); 
	  TFT_SEND_DATA(0x32); 
	  TFT_SEND_DATA(0x98);
	  
	  TFT_SEND_CMD(0x74); 	//XXX
	  TFT_SEND_DATA(0x10); 
	  TFT_SEND_DATA(0x85); 
	  TFT_SEND_DATA(0x80); 
	  TFT_SEND_DATA(0x00); 
	  TFT_SEND_DATA(0x00); 
	  TFT_SEND_DATA(0x4E); 
	  TFT_SEND_DATA(0x00);
	  
	  TFT_SEND_CMD(0x98); 		//XXX
	  TFT_SEND_DATA(0x3e); 
	  TFT_SEND_DATA(0x07); 
	  
	  TFT_SEND_CMD(0x34); 	//Tearing Effect Line Off
	  TFT_SEND_CMD(0x21); 	//Display Inversion ON

	//TFT_SEND_CMD(0x11); 	//����
	  //TFT_SEND_CMD(0x29); 	//��ʾ��
}




void TFT_clear()
{
	 TFT_SET_ADD(0,0,TFT_COLUMN_NUMBER-1,TFT_LINE_NUMBER-1);
   for(int i=0;i<76800;i++)             //Line loop
   { 
			TFT_SEND_DATA(0xF);
			TFT_SEND_DATA(0xF);
	 }
}
	
	
void TFT_full(unsigned int color)
  {
    unsigned long Line,column;
	  TFT_SET_ADD(0,0,TFT_COLUMN_NUMBER-1,TFT_LINE_NUMBER-1);
    for(Line=0;Line<TFT_LINE_NUMBER;Line++)             //Line loop
      { 
		  
		for(column=0;column<TFT_COLUMN_NUMBER;column++)	//column loop
          {
              TFT_SEND_DATA(color>>8);
			  TFT_SEND_DATA(color);
          }
      }
  }

	
void TFT_Fill(u16 x,u16 y,u16 length,u16 width,unsigned int color)
{
	u16 i,j;
	TFT_SET_ADD(x,y,x+length-1,y+width-1);
	for(i=0;i<length;i++)
	{
		for(j=0;j<width;j++)
		{
			TFT_SEND_DATA(color>>8);
			TFT_SEND_DATA(color);
		}
	}			
}

void Picture_display(u16 x,u16 y,u16 length,u16 width,const unsigned char *ptr_pic)
{
	u16 i,j;
	TFT_SET_ADD(x,y,x+length-1,y+width-1);
	for(i=0;i<length;i++)
	{
		for(j=0;j<width;j++)
		{
      TFT_SEND_DATA(*ptr_pic++);
			TFT_SEND_DATA(*ptr_pic++);
		}
	}			
}


void TFT_Page_bar()
{
	int col = TFT_COLUMN_NUMBER;
	int row = TFT_LINE_NUMBER;
	
	int c = 0;
	int r = 0;

	int c2 = 0;
	//int r2 = 0;

	int ex = 0;

	for(c=0;c<col;c++)
	{
		for(r=0;r<row;r++)
		{
			c2 = (int)(c/30);
			//r2 = (int)(r/30);
			
			ex = c2 % 8;
			//ex = r2 % 8;
			
			if(ex == 0){
				TFT_SEND_DATA(0xFF);
				TFT_SEND_DATA(0xFF);
			}else if(ex == 1){
				TFT_SEND_DATA(0x00);
				TFT_SEND_DATA(0x00);
			}else if(ex == 2){
				TFT_SEND_DATA(0x00);
				TFT_SEND_DATA(0x1F);
			}else if(ex == 3){
				TFT_SEND_DATA(0xF8);
				TFT_SEND_DATA(0x1F);
			}else if(ex == 4){
				TFT_SEND_DATA(0xFF);
				TFT_SEND_DATA(0xE0);
			}else if(ex == 5){
				TFT_SEND_DATA(0x07);
				TFT_SEND_DATA(0xFF);
			}else if(ex == 6){
				TFT_SEND_DATA(0xF8);
				TFT_SEND_DATA(0x00);
			}else if(ex == 7){
				TFT_SEND_DATA(0x07);
				TFT_SEND_DATA(0xE0);
			}
			//delay_ms(10);
		}
	}
}


void TFT_Page_border()
{
	int col = TFT_COLUMN_NUMBER;
	int row = TFT_LINE_NUMBER;
	
	int c, r;

  TFT_SET_ADD(0,0,TFT_COLUMN_NUMBER-1,TFT_LINE_NUMBER-1);

	
	for(r=0;r<row;r++)
	{
		for(c=0;c<col;c++)
		{
			if(c==0 || r==0 || c == col-1 || r == row-1)
			{
				TFT_SEND_DATA(0xFF);
				TFT_SEND_DATA(0xFF);
			}else{
				TFT_SEND_DATA(0x00);
				TFT_SEND_DATA(0x00);
			}
			//delay_ms(50);
		}
	}
}
	

void TFT_Page_net()
{
	int col = TFT_COLUMN_NUMBER;
	int row = TFT_LINE_NUMBER;
	
	int c, r;

  TFT_SET_ADD(0,0,TFT_COLUMN_NUMBER-1,TFT_LINE_NUMBER-1);
	
	
	for(c=0;c<col;c++)
	{
		for(r=0;r<row;r++)
		{
			if(r%2 == 0)
			{
				TFT_SEND_DATA(0xFF);
				TFT_SEND_DATA(0xFF);
			}else{
				TFT_SEND_DATA(0x00);
				TFT_SEND_DATA(0x00);
			}
		}
	}
}	


void TFT_Page_cell()
{
	int col = TFT_COLUMN_NUMBER;
	int row = TFT_LINE_NUMBER;
	
	int c = 0;
	int r = 0;

	int c2 = 0;
	int r2 = 0;

	int c3 = 0;
	int r3 = 0;

	TFT_SET_ADD(0,0,TFT_COLUMN_NUMBER-1,TFT_LINE_NUMBER-1);

	for(c=0;c<col;c++)
	{
		for(r=0;r<row;r++)
		{
			c2 = (int)(c/20);
			r2 = (int)(r/20);
			c3 = c2 % 2;
			r3 = r2 % 2;

			if(c3 == r3){
				TFT_SEND_DATA(0xFF);
				TFT_SEND_DATA(0xFF);
			}else{
				TFT_SEND_DATA(0x00);
				TFT_SEND_DATA(0x00);
			}			
		}
	}
}
	



void TFT_SET_ADD2(unsigned short int X,unsigned short int Y,unsigned short int X_END,unsigned short int Y_END)
{	
	TFT_SEND_CMD(0x2A);     //���ڵ�ַ����                   
    TFT_SEND_DATA(X>>8);     
    TFT_SEND_DATA(X);//start column
	TFT_SEND_DATA(X_END>>8);     
    TFT_SEND_DATA(X_END);//start column
	TFT_SEND_CMD(0x2B);     //���ڵ�ַ����                   
    TFT_SEND_DATA(Y>>8);     
    TFT_SEND_DATA(Y);		//start row
    TFT_SEND_DATA(Y_END>>8);     
    TFT_SEND_DATA(Y_END);		//start row
    TFT_SEND_CMD(0x2C);     //д������   
}

	
void TEST_A(unsigned int color)
  {
    unsigned long Line,column;
	  TFT_SET_ADD2(0,0,100,150);
    for(Line=0;Line<150;Line++)             //Line loop
      { 
		  
		for(column=0;column<100;column++)	//column loop
          {
              TFT_SEND_DATA(color>>8);
			  TFT_SEND_DATA(color);
          }
      }
  }
	
	
	
int main(void)
{
	int begin_line = 45;
	delay_ms(1);
	
	SYS_init(4);
  IO_init();

  TFT_init();
	
	int speeds = 1;

	LED_GPIO_Config(); //LED �˿ڳ�ʼ��   	
  Key_GPIO_Config();//�����˿ڳ�ʼ��
	
	TFT_full(WHITE);
//	TEST_A(BLACK);
	return 0;

	page = 0;
	
  while(1)
  {
		if( Key_Scan(GPIOB,GPIO_Pin_13) == KEY_OFF )	 //�ж�KEY1�Ƿ���
		{
			LED1( OFF );
			page++;
			if(page > 8){ page = 1; }
			
			  TFT_init2();

			if(page == 1){
				TFT_full(BLACK);
				//TFT_Page_border();
			}else if(page == 2){
				TFT_full(RED);
			}else if(page == 3){
				TFT_full(WHITE);
//				Picture_display(0,begin_line,240,16, gImage_xk_1_1);
//				begin_line = begin_line + 40;
//				Picture_display(0,begin_line,240,16, gImage_xk_1_2);
//				begin_line = begin_line + 40;
//				Picture_display(0,begin_line,240,16, gImage_xk_1_3);
//				begin_line = begin_line + 40;
//				Picture_display(0,begin_line,240,16, gImage_xk_1_4);
			}else if(page == 4){
				TFT_full(GREEN);
			}else if(page == 5){
				TFT_full(BLUE);
			}else if(page == 6){
				TFT_Page_bar();
			}else if(page == 7){
				TFT_Page_cell();
			}else if(page == 8){
				TFT_full(GREEN);
				//Picture_display(0,0,240,16,gImage_xk_1_1);
			}else{
				page = 1;
			}
			delay_ms(speeds);
		}else{
			
			LED1( ON );
		}
	}

}
